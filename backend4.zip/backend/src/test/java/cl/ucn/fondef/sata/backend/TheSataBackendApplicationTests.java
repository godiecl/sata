package cl.ucn.fondef.sata.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheSataBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
