package cl.ucn.fondef.sata.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheSataBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheSataBackendApplication.class, args);
	}

}
